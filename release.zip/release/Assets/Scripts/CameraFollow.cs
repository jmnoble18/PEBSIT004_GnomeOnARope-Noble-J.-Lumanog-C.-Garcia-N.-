// Adjusts the camera to always match the Y-position of a
// target object, within certain limits.
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;         // The object we want to match the Y position of
    public float topLimit = 10.0f;   // The highest point the camera can go
    public float bottomLimit = -10.0f; // The lowest point the camera can go
    public float followSpeed = 0.5f; // How quickly we should move toward the target
    public float startDelay = 1f;    // Delay before the camera starts following

    private float timer = 0f;
    private bool snapDone = false;   // Has the initial snap happened?

    void LateUpdate()
    {
        if (target == null) return;

        timer += Time.deltaTime;

        // Before delay is finished, do nothing
        if (timer < startDelay) return;

        Vector3 newPosition = transform.position;

        if (!snapDone)
        {
            // First frame after delay -> snap directly to target Y
            newPosition.y = target.position.y;
            snapDone = true;
        }
        else
        {
            // Smooth follow after snap
            newPosition.y = Mathf.Lerp(newPosition.y, target.position.y, followSpeed);
        }

        // Clamp to limits
        newPosition.y = Mathf.Min(newPosition.y, topLimit);
        newPosition.y = Mathf.Max(newPosition.y, bottomLimit);

        transform.position = newPosition;
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Vector3 topPoint = new Vector3(this.transform.position.x, topLimit, this.transform.position.z);
        Vector3 bottomPoint = new Vector3(this.transform.position.x, bottomLimit, this.transform.position.z);
        Gizmos.DrawLine(topPoint, bottomPoint);
    }
}
